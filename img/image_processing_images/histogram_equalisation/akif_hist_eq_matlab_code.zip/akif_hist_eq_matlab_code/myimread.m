function[array, props] = myimread(nameOfFile) % read an image and return image array,its dimensions and intensity range

props = [0,0,0]; % resmin s�ras�yla width, hight ve L de�erini al
k = 1;
fid = fopen(nameOfFile, 'r'); % sdosyay� okumak i�in a�
type = fscanf(fid, '%s', 1 ); % t�r bilgisini oku

while k < 4 % toplam 3 de�er bilgisi resimden okanacak, en ,boy, koyuluk de�eri
       str = fscanf(fid, '%s', 1 ); %bir string al      
       if(strncmp(str,'#',1) == 1) % yorum sat�r� ise ge�
           temp = fgetl(fid);
        continue;
       end
           props(k) = str2num(str); %say�ya �evir
           k = k+1;
end
   
if(strncmp(type,'P5',2) == 1)  
   F = uint8(fread(fid,[props(1),props(2)],'uint8')); %integer olarak oku resmi
   array = F';
elseif(strncmp(type,'P2',2) == 1)
   F = uint8(fscanf(fid, '%d', [props(1),props(2)])); % resmi binary olarak oku
   disp('P2 resim')
   array = F';
end

fclose(fid); % dosyay� kapat
