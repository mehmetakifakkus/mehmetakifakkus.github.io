%
% Written by Mehmet Akif AKKUS
% mail: akifakkus@ceng.metu.edu.tr
% akifsblog.com

function[] = hw1_3(I, Ihisteq) 
[F, props] = myimread(I);

imW = props(1); %width of image
imH = props(2); %height of image
imL = props(3); %L of image

nk = zeros(imL+1, 1);
prrk = zeros(imL+1, 1);
result = zeros(imL+1, 1);
MN = imH * imW;

for i = 1:imW 
    for j=1:imH 
        k = uint16(F(j,i));
        k = k+1;
        nk(k) = nk(k) + 1;  % bir yo�unluk de�erinin ka� kez ge�ti�ini bul
    end
end

for i = 1:imL+1   %yo�unluk de�erlerinin y�zdeliklerini bul
    prrk(i) = nk(i) / MN; 
end

temp = zeros(1);
for i=1:imL+1 
   temp = temp + prrk(i);
   result(i) = uint16(imL*temp);  % ? i�lemi ile yeni histogram de�erlerini bul
end

f_result = F;
for i = 1:imW %% 320
    for j=1:imH %%240
        temp  = F(j,i);
        f_result(j,i) = result(temp+1); % resmi yeniden bi�imlendir ve sonucu f_result yaz
    end
end

imshow(F);
figure, imshow(f_result);
myimwrite(Ihisteq, props, f_result);



