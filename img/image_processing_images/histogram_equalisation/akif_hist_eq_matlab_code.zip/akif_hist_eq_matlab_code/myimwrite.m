function[] = myimwrite(nameOfFile, props, array) % dosyaismi, en, boy, koyuluk ve resim

fid = fopen(nameOfFile, 'w'); % yazmak i�in a�
fprintf(fid,'%s\n', 'P5'); % P5 format�nda yaz
fprintf(fid,'%s\n', num2str(props(1))); % en
fprintf(fid,'%s\n', num2str(props(2))); % boy
fprintf(fid,'%s\n', num2str(props(3))); % L

array = array';
fwrite(fid, array); % array yaz

