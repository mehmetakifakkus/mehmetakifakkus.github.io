function[] = hw1_1(I, Ineg) 
[F, props] = myimread(I);

f_negative = 255 - F;% Bu k�s�mda negatifini buluyoruz.

myimwrite(Ineg, props, f_negative);

