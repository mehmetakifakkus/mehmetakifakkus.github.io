function[] = hw1_2(I, IsiyahBeyaz) 
[F, props] = myimread(I);

totalValue = sum(sum(F)); %% matrixteki t�m ifadelerin toplam�
threshold = uint8(totalValue / (props(1) * props(2))); %% toplam de�erin en*boy arp�m�na b�l�m�

F(F > threshold) = 255; % Resmin e�ik de�erinden b�y�k de�erleri
F(F < threshold) = 0; %Resmin e�ik de�erinden k���k� yerleri
figure,imshow(F);

myimwrite(IsiyahBeyaz, props, F);